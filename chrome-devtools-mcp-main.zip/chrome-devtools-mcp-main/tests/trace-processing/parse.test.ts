/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import '../setupDevTools.js';

import assert from 'node:assert';
import {describe, it} from 'node:test';

import sinon from 'sinon';

import {
  getTraceSummary,
  parseRawTraceBuffer,
} from '../../src/processors/PerformanceTrace.js';
import {DevTools} from '../../src/third_party/index.js';

import {loadTraceAsBuffer} from './fixtures/load.js';

describe('Trace parsing', () => {
  it('creates an isolated model instance for each parsed trace', async () => {
    const createModelSpy = sinon.spy(
      DevTools.TraceEngine.TraceModel.Model,
      'createWithAllHandlers',
    );
    const rawData = loadTraceAsBuffer('basic-trace.json.gz');

    const result1 = await parseRawTraceBuffer(rawData);
    const result2 = await parseRawTraceBuffer(rawData);

    if ('error' in result1) {
      assert.fail(`Unexpected parse failure on first trace: ${result1.error}`);
    }
    if ('error' in result2) {
      assert.fail(`Unexpected parse failure on second trace: ${result2.error}`);
    }

    sinon.assert.calledTwice(createModelSpy);
    const firstModel = createModelSpy.firstCall.returnValue;
    const secondModel = createModelSpy.secondCall.returnValue;
    assert.notStrictEqual(firstModel, secondModel);
    // Verify that each model instance retains only its own trace. If the model
    // were shared, subsequent parses would accumulate in `#traces` and increase size.
    assert.strictEqual(firstModel.size(), 1);
    assert.strictEqual(secondModel.size(), 1);
  });

  it('can parse a Uint8Array from Tracing.stop()', async () => {
    const rawData = loadTraceAsBuffer('basic-trace.json.gz');
    const result = await parseRawTraceBuffer(rawData);
    if ('error' in result) {
      assert.fail(`Unexpected parse failure: ${result.error}`);
    }
    assert.ok(result.parsedTrace);
    assert.ok(result.insights);
  });

  it('can format results of a trace', async t => {
    const rawData = loadTraceAsBuffer('web-dev-with-commit.json.gz');
    const result = await parseRawTraceBuffer(rawData);
    if ('error' in result) {
      assert.fail(`Unexpected parse failure: ${result.error}`);
    }
    assert.ok(result.parsedTrace);
    assert.ok(result.insights);

    const output = getTraceSummary(result);
    t.assert.snapshot(output);
  });

  it('will return a message if there is an error', async () => {
    const result = await parseRawTraceBuffer(undefined);
    assert.deepEqual(result, {
      error: 'No buffer was provided.',
    });
  });

  it('does not clobber file metadata with undefined caller properties', async () => {
    const rawData = loadTraceAsBuffer('web-dev-with-commit.json.gz');
    // The caller passes explicit undefined for networkThrottling (matching production behavior when conditions are null).
    const result = await parseRawTraceBuffer(rawData, {
      cpuThrottling: undefined,
      networkThrottling: undefined,
    });
    if ('error' in result) {
      assert.fail(`Unexpected parse failure: ${result.error}`);
    }
    const summary = getTraceSummary(result);
    // Verify that throttling from file metadata is preserved rather than reverting to 'none'.
    assert.ok(summary.includes('CPU throttling: 1x'));
    assert.ok(summary.includes('Network throttling: No throttling'));
  });

  it('overrides file metadata when caller specifies defined throttling options', async () => {
    const rawData = loadTraceAsBuffer('web-dev-with-commit.json.gz');
    // The caller passes explicit defined overrides.
    const result = await parseRawTraceBuffer(rawData, {
      cpuThrottling: 4,
      networkThrottling: 'Slow 3G',
    });
    if ('error' in result) {
      assert.fail(`Unexpected parse failure: ${result.error}`);
    }
    const summary = getTraceSummary(result);
    // Verify that caller-specified throttling overrides file metadata.
    assert.ok(summary.includes('CPU throttling: 4x'));
    assert.ok(summary.includes('Network throttling: Slow 3G'));
  });
});
