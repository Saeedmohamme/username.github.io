/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import assert from 'node:assert';
import {describe, it} from 'node:test';

import sinon from 'sinon';

import type {ParsedArguments} from '../../src/config/mcp-options.js';
import type {McpContext} from '../../src/McpContext.js';
import type {McpResponse} from '../../src/McpResponse.js';
import {TextSnapshot} from '../../src/TextSnapshot.js';
import {
  executeThirdPartyDeveloperTool,
  listThirdPartyDeveloperTools,
} from '../../src/tools/thirdPartyDeveloper.js';
import {createHandlerMocks} from '../mocks.js';
import {getTextContent, withMcpContext} from '../utils.js';

describe('thirdPartyDeveloperTools', () => {
  describe('list_3p_developer_tools', () => {
    it('lists tools', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);

          await page.pptrPage.evaluate(() => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {
                    type: 'object',
                    properties: {
                      arg: {type: 'string'},
                    },
                  },
                  execute: () => 'result',
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith(mockToolGroup);
            });
          });

          await listThirdPartyDeveloperTools(args).handler(
            {params: {}, page},
            response,
            context,
          );

          const result = await response.handle(context);
          // @ts-expect-error `structuredContent` has `thirdPartyDeveloperTools`
          const groups = result.structuredContent.thirdPartyDeveloperTools;
          assert.strictEqual(groups.length, 1);
          const actualGroup = groups[0];
          assert.strictEqual(actualGroup.name, 'test-group');
          assert.strictEqual(actualGroup.description, 'test description');
          assert.strictEqual(actualGroup.tools.length, 1);
          assert.strictEqual(actualGroup.tools[0].name, 'test-tool');
          assert.strictEqual(
            actualGroup.tools[0].description,
            'test tool description',
          );
          assert.deepEqual(actualGroup.tools[0].inputSchema, {
            type: 'object',
            properties: {
              arg: {type: 'string'},
            },
          });
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('handles empty response', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);
          await page.pptrPage.evaluate(() => {
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith({});
            });
          });

          await listThirdPartyDeveloperTools(args).handler(
            {params: {}, page},
            response,
            context,
          );

          const result = await response.handle(context);
          assert.ok(result.structuredContent);
          assert.deepStrictEqual(result.structuredContent, {
            thirdPartyDeveloperTools: [],
          });
          const firstContent = result.content[0];
          assert.ok(firstContent);
          assert.strictEqual(
            getTextContent(firstContent),
            '## Third-party developer tools\nNo third-party developer tools available.',
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('handles no response', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);
          await page.pptrPage.evaluate(() => {
            window.addEventListener('devtoolstooldiscovery', () => {
              // do nothing
            });
          });

          await listThirdPartyDeveloperTools(args).handler(
            {params: {}, page},
            response,
            context,
          );

          const result = await response.handle(context);
          assert.ok(result.structuredContent);
          assert.deepStrictEqual(result.structuredContent, {
            thirdPartyDeveloperTools: [],
          });
          const firstContent = result.content[0];
          assert.ok(firstContent);
          assert.strictEqual(
            getTextContent(firstContent),
            '## Third-party developer tools\nNo third-party developer tools available.',
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('handles no eventListener', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);
          await listThirdPartyDeveloperTools(args).handler(
            {params: {}, page},
            response,
            context,
          );

          const result = await response.handle(context);
          assert.ok(result.structuredContent);
          assert.deepStrictEqual(result.structuredContent, {
            thirdPartyDeveloperTools: [],
          });
          const firstContent = result.content[0];
          assert.ok(firstContent);
          assert.strictEqual(
            getTextContent(firstContent),
            '## Third-party developer tools\nNo third-party developer tools available.',
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('lists multiple toolgroups', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);

          await page.pptrPage.evaluate(() => {
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith?.({
                name: 'group-1',
                description: 'desc-1',
                tools: [
                  {
                    name: 'tool-1',
                    description: 'tool-1-desc',
                    inputSchema: {},
                    execute: () => 'r1',
                  },
                ],
              });
            });
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith?.({
                name: 'group-2',
                description: 'desc-2',
                tools: [
                  {
                    name: 'tool-2',
                    description: 'tool-2-desc',
                    inputSchema: {},
                    execute: () => 'r2',
                  },
                ],
              });
            });
          });

          await listThirdPartyDeveloperTools(args).handler(
            {params: {}, page},
            response,
            context,
          );

          const result = await response.handle(context);
          const actualGroups =
            // @ts-expect-error structuredContent has `thirdPartyDeveloperTools`
            result.structuredContent.thirdPartyDeveloperTools;
          assert.ok(actualGroups);
          assert.strictEqual(actualGroups.length, 2);
          assert.strictEqual(actualGroups[0].name, 'group-1');
          assert.strictEqual(actualGroups[1].name, 'group-2');
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('clears window.__dtmcp.toolGroups on subsequent discoverThirdPartyDeveloperTools calls', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);

          await page.pptrPage.evaluate(() => {
            const mockToolGroup = {
              name: 'group-1',
              description: 'desc-1',
              tools: [
                {
                  name: 'tool-1',
                  description: 'tool-1-desc',
                  inputSchema: {},
                  execute: () => 'r1',
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith(mockToolGroup);
            });
          });

          await listThirdPartyDeveloperTools(args).handler(
            {params: {}, page},
            response,
            context,
          );
          await response.handle(context);

          let groupsLength = await page.pptrPage.evaluate(
            () => window.__dtmcp?.toolGroups?.length,
          );
          assert.strictEqual(groupsLength, 1);

          await listThirdPartyDeveloperTools(args).handler(
            {params: {}, page},
            response,
            context,
          );
          await response.handle(context);

          groupsLength = await page.pptrPage.evaluate(
            () => window.__dtmcp?.toolGroups?.length,
          );
          assert.strictEqual(groupsLength, 1);
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });
  });

  describe('execute_3p_developer_tool', () => {
    async function setupThirdPartyDeveloperTools(
      response: McpResponse,
      context: McpContext,
      args: ParsedArguments,
      evaluateFn: () => void,
    ) {
      const page = await context.newPage();
      response.setPage(page);
      await page.pptrPage.evaluate(evaluateFn);
      await listThirdPartyDeveloperTools(args).handler(
        {params: {}, page},
        response,
        context,
      );
      await response.handle(context);
    }

    it('executes a tool', async () => {
      const {page, context, response, args} = createHandlerMocks({
        categoryExperimentalThirdParty: true,
      });
      page.discoverThirdPartyDeveloperTools.resolves([
        {
          name: 'test-group',
          description: 'test description',
          tools: [
            {
              name: 'test-tool',
              description: 'test tool description',
              inputSchema: {
                type: 'object',
                properties: {
                  arg: {type: 'string'},
                },
                required: ['arg'],
              },
            },
          ],
        },
      ]);

      await executeThirdPartyDeveloperTool(args).handler(
        {
          params: {
            toolName: 'test-tool',
            params: JSON.stringify({arg: 'value'}),
          },
          page,
        },
        response,
        context,
      );

      sinon.assert.calledOnceWithExactly(page.discoverThirdPartyDeveloperTools);
      sinon.assert.calledOnceWithExactly(
        page.executeThirdPartyDeveloperTool,
        'test-tool',
        {arg: 'value'},
        response,
      );
      sinon.assert.callOrder(
        page.discoverThirdPartyDeveloperTools,
        page.executeThirdPartyDeveloperTool,
      );
    });

    it('throws if tool not found in list', async () => {
      const {page, context, response, args} = createHandlerMocks({
        categoryExperimentalThirdParty: true,
      });
      page.discoverThirdPartyDeveloperTools.resolves([
        {
          name: 'test-group',
          description: 'test description',
          tools: [],
        },
      ]);

      await assert.rejects(
        async () => {
          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'missing-tool',
                params: JSON.stringify({}),
              },
              page,
            },
            response,
            context,
          );
        },
        {message: /Tool missing-tool not found/},
      );

      sinon.assert.calledOnceWithExactly(page.discoverThirdPartyDeveloperTools);
      sinon.assert.notCalled(page.executeThirdPartyDeveloperTool);
    });

    it('rejects JSON array params', async () => {
      const {page, context, response, args} = createHandlerMocks();
      await assert.rejects(
        executeThirdPartyDeveloperTool(args).handler(
          {
            params: {
              toolName: 'test-tool',
              params: '[]',
            },
            page,
          },
          response,
          context,
        ),
        {message: /Parsed params is not an object/},
      );
    });

    it('throws if parameters are invalid', async () => {
      const {page, context, response, args} = createHandlerMocks({
        categoryExperimentalThirdParty: true,
      });
      page.discoverThirdPartyDeveloperTools.resolves([
        {
          name: 'test-group',
          description: 'test description',
          tools: [
            {
              name: 'test-tool',
              description: 'test tool description',
              inputSchema: {
                type: 'object',
                properties: {
                  arg: {type: 'string'},
                },
                required: ['arg'],
              },
            },
          ],
        },
      ]);

      await assert.rejects(
        async () => {
          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}), // Missing required 'arg'
              },
              page,
            },
            response,
            context,
          );
        },
        {message: /Invalid parameters for tool test-tool/},
      );

      sinon.assert.calledOnceWithExactly(page.discoverThirdPartyDeveloperTools);
      sinon.assert.notCalled(page.executeThirdPartyDeveloperTool);
    });

    it('handles JSON result', async () => {
      await withMcpContext(
        async (response, context, args) => {
          await setupThirdPartyDeveloperTools(response, context, args, () => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: () => ({foo: 'bar'}),
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith(mockToolGroup);
            });
          });

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page: context.getSelectedMcpPage(),
            },
            response,
            context,
          );
          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify({foo: 'bar'}, null, 2),
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('replaces uid with element handle in params', async () => {
      await withMcpContext(async (response, context, args) => {
        const page = await context.newPage();
        response.setPage(page);

        await page.pptrPage.evaluate(() => {
          const mockToolGroup = {
            name: 'test-group',
            description: 'test description',
            tools: [
              {
                name: 'test-tool',
                description: 'test tool description',
                inputSchema: {
                  type: 'object',
                  properties: {
                    element: {type: 'object'},
                  },
                  required: ['element'],
                },
                execute: async (toolArgs: Record<string, unknown>) => {
                  const el = toolArgs.element;
                  if (el instanceof HTMLElement) {
                    return {
                      isElement: true,
                      tagName: el.tagName,
                      id: el.id,
                    };
                  }
                  return {
                    isElement: false,
                    tagName: '',
                    id: '',
                  };
                },
              },
            ],
          };
          window.addEventListener('devtoolstooldiscovery', (e: Event) => {
            if ('respondWith' in e && typeof e.respondWith === 'function') {
              e.respondWith(mockToolGroup);
            }
          });
        });

        await page.pptrPage.evaluate(() => {
          const div = document.createElement('div');
          div.id = 'test-id';
          document.body.appendChild(div);
        });

        const handle = await page.pptrPage.$('#test-id');
        if (!handle) {
          throw new Error('Handle not found');
        }

        page.getElementByUid = async (uid: string) => {
          if (uid === 'some-uid') {
            return handle;
          }
          throw new Error('Not found');
        };

        await executeThirdPartyDeveloperTool(args).handler(
          {
            params: {
              toolName: 'test-tool',
              params: JSON.stringify({element: {uid: 'some-uid'}}),
            },
            page,
          },
          response,
          context,
        );

        assert.strictEqual(
          response.responseLines[0],
          JSON.stringify(
            {
              isElement: true,
              tagName: 'DIV',
              id: 'test-id',
            },
            null,
            2,
          ),
        );
      });
    });

    it('processToolResult replaces functions with "<Function object>"', async () => {
      await withMcpContext(
        async (response, context, args) => {
          await setupThirdPartyDeveloperTools(response, context, args, () => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: () => ({
                    foo: 'bar',
                    func: () => undefined,
                  }),
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith(mockToolGroup);
            });
          });

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page: context.getSelectedMcpPage(),
            },
            response,
            context,
          );
          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify({foo: 'bar', func: '<Function object>'}, null, 2),
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('processToolResult replaces circular references with "<Circular reference>"', async () => {
      await withMcpContext(
        async (response, context, args) => {
          await setupThirdPartyDeveloperTools(response, context, args, () => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: () => {
                    const obj: Record<string, unknown> = {foo: 'bar'};
                    obj.self = obj;
                    return obj;
                  },
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith(mockToolGroup);
            });
          });

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page: context.getSelectedMcpPage(),
            },
            response,
            context,
          );
          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify({foo: 'bar', self: '<Circular reference>'}, null, 2),
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('processToolResult replaces non-plain objects with "<ConstructorName instance>"', async () => {
      await withMcpContext(
        async (response, context, args) => {
          await setupThirdPartyDeveloperTools(response, context, args, () => {
            class CustomClass {
              val = 'value';
            }
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: () => ({
                    foo: 'bar',
                    custom: new CustomClass(),
                  }),
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith(mockToolGroup);
            });
          });

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page: context.getSelectedMcpPage(),
            },
            response,
            context,
          );
          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify(
              {foo: 'bar', custom: '<CustomClass instance>'},
              null,
              2,
            ),
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('processToolResult handles symbols, bigints, circular arrays, shared references, and null-prototype objects', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);

          await page.pptrPage.evaluate(() => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: async () => {
                    const circularArr: unknown[] = ['item'];
                    circularArr.push(circularArr);
                    const sharedObj = {sharedKey: 'sharedVal'};
                    const nullProtoObj: Record<string, unknown> =
                      Object.create(null);
                    nullProtoObj.key = 'val';
                    const AnonymousClass = (() => class {})();
                    return {
                      sym: Symbol('test-sym'),
                      big: BigInt(42),
                      circularArr,
                      shared1: sharedObj,
                      shared2: sharedObj,
                      nullProtoObj,
                      anonInstance: new AnonymousClass(),
                    };
                  },
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              if ('respondWith' in e && typeof e.respondWith === 'function') {
                e.respondWith(mockToolGroup);
              }
            });
          });

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page,
            },
            response,
            context,
          );
          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify(
              {
                sym: 'Symbol(test-sym)',
                big: '42n',
                circularArr: ['item', '<Circular reference>'],
                shared1: {sharedKey: 'sharedVal'},
                shared2: {sharedKey: 'sharedVal'},
                nullProtoObj: {key: 'val'},
                anonInstance: '<Object instance>',
              },
              null,
              2,
            ),
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('stashDOMElement stashes elements and returns UID', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);

          await page.pptrPage.evaluate(() => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: async () => {
                    const div = document.createElement('div');
                    div.id = 'test-element';
                    document.body.appendChild(div);
                    return div;
                  },
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              if ('respondWith' in e && typeof e.respondWith === 'function') {
                e.respondWith(mockToolGroup);
              }
            });
          });

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page,
            },
            response,
            context,
          );

          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify({uid: '1_1'}, null, 2),
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('creates a new snapshot if the third-party developer tool response contains a DOM element', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);

          await page.pptrPage.evaluate(() => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: async () => {
                    const div = document.createElement('div');
                    div.id = 'test-element';
                    document.body.appendChild(div);
                    return div;
                  },
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              if ('respondWith' in e && typeof e.respondWith === 'function') {
                e.respondWith(mockToolGroup);
              }
            });
          });

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page,
            },
            response,
            context,
          );

          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify({uid: '1_1'}, null, 2),
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('does not create a new snapshot if the third-party developer tool response does not contain a DOM element', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);

          await page.pptrPage.evaluate(() => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: async () => {
                    return 'simple-result';
                  },
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              if ('respondWith' in e && typeof e.respondWith === 'function') {
                e.respondWith(mockToolGroup);
              }
            });
          });

          const stubSnapshot = sinon
            .stub(TextSnapshot, 'create')
            .resolves(sinon.createStubInstance(TextSnapshot));

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page,
            },
            response,
            context,
          );

          assert.ok(
            stubSnapshot.notCalled,
            'Expected TextSnapshot.create not to be called',
          );
          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify('simple-result', null, 2),
          );

          stubSnapshot.restore();
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('executes a tool after the page reloads itself', async () => {
      await withMcpContext(
        async (response, context, args) => {
          const page = await context.newPage();
          response.setPage(page);

          await page.pptrPage.evaluateOnNewDocument(() => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: () => ({reloaded: true}),
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              if ('respondWith' in e && typeof e.respondWith === 'function') {
                e.respondWith(mockToolGroup);
              }
            });
          });
          await page.pptrPage.reload();

          await listThirdPartyDeveloperTools(args).handler(
            {params: {}, page},
            response,
            context,
          );
          await response.handle(context);

          await page.pptrPage.reload();

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page,
            },
            response,
            context,
          );
          assert.strictEqual(
            response.responseLines[0],
            JSON.stringify({reloaded: true}, null, 2),
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('throws if tool is no longer exposed after the page reloads itself', async () => {
      await withMcpContext(
        async (response, context, args) => {
          await setupThirdPartyDeveloperTools(response, context, args, () => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: () => ({foo: 'bar'}),
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              if ('respondWith' in e && typeof e.respondWith === 'function') {
                e.respondWith(mockToolGroup);
              }
            });
          });

          const page = context.getSelectedMcpPage();
          await page.pptrPage.reload();

          await assert.rejects(
            async () => {
              await executeThirdPartyDeveloperTool(args).handler(
                {
                  params: {
                    toolName: 'test-tool',
                    params: JSON.stringify({}),
                  },
                  page,
                },
                response,
                context,
              );
            },
            {message: /Tool test-tool not found/},
          );
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });

    it('disposes old handles when executing third party developer tools', async () => {
      await withMcpContext(
        async (response, context, args) => {
          await setupThirdPartyDeveloperTools(response, context, args, () => {
            const mockToolGroup = {
              name: 'test-group',
              description: 'test description',
              tools: [
                {
                  name: 'test-tool',
                  description: 'test tool description',
                  inputSchema: {},
                  execute: () => {
                    const div = document.createElement('div');
                    document.body.appendChild(div);
                    return div;
                  },
                },
              ],
            };
            window.addEventListener('devtoolstooldiscovery', (e: Event) => {
              // @ts-expect-error Event has `respondWith`
              e.respondWith(mockToolGroup);
            });
          });

          const page = context.getSelectedMcpPage();
          if (!page) {
            assert.fail('No page found');
          }

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page,
            },
            response,
            context,
          );

          const firstHandles = [...page.extraHandles];
          assert.strictEqual(firstHandles.length, 1);
          // @ts-expect-error Internal Puppeteer API
          assert.ok(!firstHandles[0].disposed);

          await executeThirdPartyDeveloperTool(args).handler(
            {
              params: {
                toolName: 'test-tool',
                params: JSON.stringify({}),
              },
              page,
            },
            response,
            context,
          );

          const secondHandles = [...page.extraHandles];
          assert.strictEqual(secondHandles.length, 1);
          assert.notStrictEqual(firstHandles[0], secondHandles[0]);
          // @ts-expect-error Internal Puppeteer API
          assert.ok(!secondHandles[0].disposed);
          // @ts-expect-error Internal Puppeteer API
          assert.ok(firstHandles[0].disposed);
        },
        undefined,
        {categoryExperimentalThirdParty: true},
      );
    });
  });
});
