/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import {zod} from '../third_party/index.js';

import {ToolCategory} from './categories.js';
import {definePageTool, type PageToolFactory} from './ToolDefinition.js';

export const listWebMcpTools: PageToolFactory = definePageTool(() => ({
  name: 'list_webmcp_tools',
  description: `Lists all WebMCP tools the page exposes (excluding debugging tools, which are exposed via 'list_3p_developer_tools').`,
  annotations: {
    category: ToolCategory.WEBMCP,
    readOnlyHint: true,
  },
  schema: {},
  blockedByDialog: false,
  concurrency: 'page',
  verifyFilesSchema: {},
  handler: async (_request, response) => {
    response.setListWebMcpTools();
  },
}));

export const executeWebMcpTool: PageToolFactory = definePageTool(() => ({
  name: 'execute_webmcp_tool',
  description: `Executes a WebMCP tool exposed by the page (for debugging tools, use 'execute_3p_developer_tool').`,
  annotations: {
    category: ToolCategory.WEBMCP,
    readOnlyHint: false,
  },
  schema: {
    toolName: zod.string().describe('The name of the WebMCP tool to execute'),
    input: zod
      .string()
      .optional()
      .describe('The JSON-stringified parameters to pass to the WebMCP tool'),
  },
  blockedByDialog: false,
  concurrency: 'page',
  verifyFilesSchema: {},
  handler: async (request, response) => {
    const toolName = request.params.toolName;

    let input: Record<string, unknown> = {};
    if (request.params.input) {
      try {
        const parsed = JSON.parse(request.params.input);
        if (
          typeof parsed === 'object' &&
          parsed !== null &&
          !Array.isArray(parsed)
        ) {
          input = parsed;
        } else {
          throw new Error('Parsed input is not an object');
        }
      } catch (e) {
        const errorMessage = e instanceof Error ? e.message : String(e);
        throw new Error(`Failed to parse input as JSON: ${errorMessage}`);
      }
    }

    const tools = request.page.getWebMcpTools();
    const tool = tools.find(t => t.name === toolName);
    if (!tool) {
      throw new Error(`Tool ${toolName} not found`);
    }

    const {status, output, errorText, exception} = await tool.execute(input);
    const error = exception?.description ?? exception?.value ?? errorText;
    response.appendResponseLine(
      JSON.stringify({status, output, error}, null, 2),
    );
  },
}));
